﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace DanmakU {

public struct DanmakuCollision {
  public Danmaku Danmaku;
  public RaycastHit2D RaycastHit;
}

}